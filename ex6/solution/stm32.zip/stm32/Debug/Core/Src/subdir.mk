################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Core/Src/app.cpp 

C_SRCS += \
../Core/Src/CycleCounter.c \
../Core/Src/gpio.c \
../Core/Src/main.c \
../Core/Src/memorymap.c \
../Core/Src/stm32u5xx_hal_msp.c \
../Core/Src/stm32u5xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32u5xx.c \
../Core/Src/usart.c 

C_DEPS += \
./Core/Src/CycleCounter.d \
./Core/Src/gpio.d \
./Core/Src/main.d \
./Core/Src/memorymap.d \
./Core/Src/stm32u5xx_hal_msp.d \
./Core/Src/stm32u5xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32u5xx.d \
./Core/Src/usart.d 

OBJS += \
./Core/Src/CycleCounter.o \
./Core/Src/app.o \
./Core/Src/gpio.o \
./Core/Src/main.o \
./Core/Src/memorymap.o \
./Core/Src/stm32u5xx_hal_msp.o \
./Core/Src/stm32u5xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32u5xx.o \
./Core/Src/usart.o 

CPP_DEPS += \
./Core/Src/app.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m33 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32U585xx -DCMSIS_NN -c -I../Core/Inc -I../Drivers/STM32U5xx_HAL_Driver/Inc -I../Drivers/STM32U5xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32U5xx/Include -I../Drivers/CMSIS/Include -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/Core/Include" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/DSP/Include" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/DSP/PrivateInclude" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/NN/Include" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/flatbuffers" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/gemmlowp" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/kissfft" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/ruy" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/flatbuffers/include" -I"C:/workspaces/ml_on_mcu/exercise6/Core/Inc/models" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.cpp Core/Src/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m33 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32U585xx -DCMSIS_NN -c -I../Core/Inc -I../Drivers/STM32U5xx_HAL_Driver/Inc -I../Drivers/STM32U5xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32U5xx/Include -I../Drivers/CMSIS/Include -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/Core/Include" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/DSP/Include" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/DSP/PrivateInclude" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/NN/Include" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/flatbuffers/include" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/gemmlowp" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/kissfft" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/ruy" -I"C:/workspaces/ml_on_mcu/exercise6/Core/Inc/models" -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/CycleCounter.cyclo ./Core/Src/CycleCounter.d ./Core/Src/CycleCounter.o ./Core/Src/CycleCounter.su ./Core/Src/app.cyclo ./Core/Src/app.d ./Core/Src/app.o ./Core/Src/app.su ./Core/Src/gpio.cyclo ./Core/Src/gpio.d ./Core/Src/gpio.o ./Core/Src/gpio.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/memorymap.cyclo ./Core/Src/memorymap.d ./Core/Src/memorymap.o ./Core/Src/memorymap.su ./Core/Src/stm32u5xx_hal_msp.cyclo ./Core/Src/stm32u5xx_hal_msp.d ./Core/Src/stm32u5xx_hal_msp.o ./Core/Src/stm32u5xx_hal_msp.su ./Core/Src/stm32u5xx_it.cyclo ./Core/Src/stm32u5xx_it.d ./Core/Src/stm32u5xx_it.o ./Core/Src/stm32u5xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32u5xx.cyclo ./Core/Src/system_stm32u5xx.d ./Core/Src/system_stm32u5xx.o ./Core/Src/system_stm32u5xx.su ./Core/Src/usart.cyclo ./Core/Src/usart.d ./Core/Src/usart.o ./Core/Src/usart.su

.PHONY: clean-Core-2f-Src

