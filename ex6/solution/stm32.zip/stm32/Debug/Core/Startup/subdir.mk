################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
../Core/Startup/startup_stm32u585aiixq.s 

S_DEPS += \
./Core/Startup/startup_stm32u585aiixq.d 

OBJS += \
./Core/Startup/startup_stm32u585aiixq.o 


# Each subdirectory must supply rules for building sources it contributes
Core/Startup/%.o: ../Core/Startup/%.s Core/Startup/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m33 -g3 -DDEBUG -c -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/Core/Include" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/DSP/Include" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/DSP/PrivateInclude" -I"C:/workspaces/ml_on_mcu/exercise6/Drivers/CMSIS/NN/Include" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/flatbuffers" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/gemmlowp" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/kissfft" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/ruy" -I"C:/workspaces/ml_on_mcu/exercise6/Core/Inc/models" -I"C:/workspaces/ml_on_mcu/exercise6/tensorflow_lite/third_party/flatbuffers/include" -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-Core-2f-Startup

clean-Core-2f-Startup:
	-$(RM) ./Core/Startup/startup_stm32u585aiixq.d ./Core/Startup/startup_stm32u585aiixq.o

.PHONY: clean-Core-2f-Startup

